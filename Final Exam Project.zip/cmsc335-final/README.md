**Submitted by:** Kai Chen (kaiichen)

**Group Members:** Lindsey Song (lsong125), Kai Chen (kaiichen)

**App Description:** Allows users to register, "adopt" (add) random dogs, store their registration and dogs, view their selected random dogs, and remove their user registration and return all the dogs "adopted"

**Youtube Video Link:** [YouTube Link](https://youtu.be/NFjZl17ucqU)
 
**APIs:** DogAPI (https://dog.ceo/dog-api/)

**Contact Email:** kaiichen@terpmail.umd.edu

**Render Website Link for Our Project:** https://dog-center.onrender.com
